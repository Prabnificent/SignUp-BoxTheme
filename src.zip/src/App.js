import logo from './logo.svg';
import './App.css';
import Login from './components/Login';
import SignUp from './components/SignUp';
import { useEffect, useState } from 'react';
import { ThemeProvider, useTheme } from './ThemeContext';
function App() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  useEffect(() => {
    setEmail(localStorage.getItem("email"));
    setPassword(localStorage.getItem("password"));
  }, [])
  return (
    <div className="App">
      <ThemeProvider>
        {email && password ? <Login /> : <SignUp />}
      </ThemeProvider>
    </div>
  );
}

export default App;
