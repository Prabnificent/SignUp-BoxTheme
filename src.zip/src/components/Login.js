import React, { useState } from 'react'
import Boxes from './Boxes';
import { useTheme } from '../ThemeContext';
const Login = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [loggedIn, setLoggedIn] = useState(false);
    const [error, setError] = useState("");
    const {theme, toggleTheme} = useTheme()
    console.log(theme, "theme", toggleTheme);
    const handleSubmit = (e) => {
        e.preventDefault();
        const emailFromLocal = localStorage.getItem("email");
        const passwordFromLocal = localStorage.getItem("password");
        if (emailFromLocal === email && passwordFromLocal === password) {
            setError("");
            setLoggedIn(true)
        } else {
            setError("Please check your credentials")
        }
    }
  return (
    <section className={`login-container ${theme}`}>
        <button onClick={toggleTheme}>Theme change</button>
        {loggedIn ? <Boxes /> : <form onSubmit={handleSubmit} className='form'>
        <h2>Login Page</h2>
        <section className='login'>
            <div className='email'>
                <label>Enter Email to Login</label>
                <input type='email' value={email} onChange={(e) => setEmail(e.target.value)}/>
            </div>
            
            <div className='password'>
                <label>Enter Password to login</label>
                <input type='password' value={password} onChange={(e) => setPassword(e.target.value)}/>
            </div>
            <div>
                <button className='submit' type='submit' >Login</button>
            </div>
        </section>
        
    </form>}
    </section>
  )
}

export default Login