import React, { useState } from 'react'
import { useTheme } from '../ThemeContext';
const SignUp = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const {theme, toggleTheme} = useTheme();

    const handleSubmit = (e) => {
        e.preventDefault();
        localStorage.setItem("email", email);
        localStorage.setItem("password", password);
    }
  return (
    <section className={`signup-container ${theme}`}>
         <button onClick={toggleTheme}>Theme change</button>
        <form className='form' onSubmit={handleSubmit}>
            <h2>SignUp Page</h2>
            <section className='login'>
                <div className='email'>
                    <label>Please Enter Email</label>
                    <input type='email' value={email} onChange={(e) => setEmail(e.target.value)}/>
                </div>
                
                <div className='password'>
                    <label>Please Enter Password</label>
                    <input type='password' value={password} onChange={(e) => setPassword(e.target.value)}/>
                </div>
                <div>
                    <button className='submit' type='submit' >Sign up</button>
                </div>
            </section>
            
        </form>
    </section>
  )
}

export default SignUp