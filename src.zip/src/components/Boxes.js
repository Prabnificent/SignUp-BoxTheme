import React, { useState } from 'react'
import Modal from './Modal';
const Boxes = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [selectedBox, setSelectedBox] = useState(null);
    const Boxes = ["Box1", "Box2", "Box3", "Box4"];
    const handleBoxClick = (box) => {
        setSelectedBox(box);
        setIsOpen(true);
    }
    const handleLabelChange = (label) => {
        const updatedBoxes = [...Boxes];
        updatedBoxes[selectedBox] = label;

    }
  return (
    <div>
        {Boxes?.map((box, index) => <div key={index} onClick={() => handleBoxClick(box)}>{box}</div>)}
        {isOpen && <Modal box={selectedBox} onEnter={handleLabelChange}/>}
    </div>
  )
}

export default Boxes