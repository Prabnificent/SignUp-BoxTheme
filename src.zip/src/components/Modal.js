import React, { useState } from 'react'

const Modal = ({box}) => {
    const [value, setValue] = useState("");
    console.log("box", box);
    // const handleKeyDown = (e) => {
    //     if (e.key === "Enter") {

    //     }
    // }
  return (
    <div className='modal'>
        
        <input value={value} onChange={(e) => setValue(e.target.value)}/>
    </div>
  )
}

export default Modal